// Promote real exported application actions; never substitute OS settings.
import Shell from 'gi://Shell';
import { _ } from '../i18n.js';
export function buildMacApplicationMenu(name, app, window, exported) {
    const nodes = [];
    function visit(items) {
        for (const item of items ?? []) {
            if (item.activate && item.label) nodes.push(item);
            if (item.children) visit(item.children);
        }
    }
    visit(exported?.appMenuChildren);
    for (const menu of exported?.topLevelMenus ?? []) visit(menu.children);
    const find = regex => nodes.find(item => regex.test(item.label.replace(/[.…]/g, '').trim()));
    const about = find(/^About\b/i);
    const settings = find(/^(Settings|Preferences|Options)$/i);
    const updates = find(/^Check for Updates/i);
    const logout = find(/^(Log Out|Sign Out)$/i);
    const quit = find(/^(Quit|Exit)\b/i);
    const ownWindows = () => app?.get_windows?.() ?? (window ? [window] : []);
    const children = [about ?? {label: _('About %s').replace('%s', name), sensitive: false},
        {type: 'separator'}, settings ?? {label: _('Settings…'), sensitive: false}];
    if (updates) children.push(updates);
    if (logout) children.push(logout);
    children.push({type: 'separator'},
        {label: _('Hide %s').replace('%s', name), activate: () => {
            for (const w of ownWindows()) if (w.can_minimize()) w.minimize();
        }},
        {label: _('Hide Others'), activate: () => {
            const own = new Set(ownWindows());
            for (const actor of global.get_window_actors()) {
                const w = actor.meta_window;
                if (w && !own.has(w) && !w.is_skip_taskbar() && w.can_minimize()) w.minimize();
            }
        }},
        {label: _('Show All'), activate: () => {
            for (const actor of global.get_window_actors()) {
                const w = actor.meta_window;
                if (w?.minimized && !w.is_skip_taskbar()) w.unminimize();
            }
        }}, {type: 'separator'}, quit ?? {
            label: _('Close All Windows'), activate: () => {
                for (const w of ownWindows()) w.delete(global.get_current_time());
            }
        });
    return children;
}
