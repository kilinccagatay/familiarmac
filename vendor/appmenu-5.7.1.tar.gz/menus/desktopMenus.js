// Finder-style desktop actions backed by the installed Files application.
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import { _ } from '../i18n.js';

function open(uri) {
    Gio.AppInfo.launch_default_for_uri(uri, global.create_app_launch_context(0, -1));
}
function folder(which) {
    return Gio.File.new_for_path(GLib.get_user_special_dir(which) || GLib.get_home_dir()).get_uri();
}
function filesAction(name) {
    Gio.DBus.session.call('org.gnome.Nautilus', '/org/gnome/Nautilus', 'org.gtk.Actions', 'Activate',
        new GLib.Variant('(sava{sv})', [name, [], {}]), null, Gio.DBusCallFlags.NONE, -1, null,
        (connection, result) => { try { connection.call_finish(result); } catch (e) { Main.notifyError('Files', e.message); } });
}
function newFolder() {
    const desktop = Gio.File.new_for_uri(folder(GLib.UserDirectory.DIRECTORY_DESKTOP));
    for (let n = 0; n < 1000; n++) {
        const item = desktop.get_child(n ? `Untitled Folder ${n}` : 'Untitled Folder');
        try {
            item.make_directory(null);
            Gio.DBus.session.call('org.freedesktop.FileManager1', '/org/freedesktop/FileManager1',
                'org.freedesktop.FileManager1', 'ShowItems', new GLib.Variant('(ass)', [[item.get_uri()], '']),
                null, Gio.DBusCallFlags.NONE, -1, null, null);
            return;
        } catch (e) {
            if (e.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.EXISTS)) continue;
            Main.notifyError('New Folder', e.message); return;
        }
    }
}
export function buildDesktopMenus() {
    const item = (label, activate) => ({label: _(label), activate});
    const disabled = label => ({label: _(label), sensitive: false});
    const sep = {type: 'separator'};
    return [
        {label: 'Finder', children: [item('About Files', () => filesAction('about')), sep,
            item('Settings…', () => filesAction('preferences')), sep,
            item('New Finder Window', () => filesAction('new-window'))]},
        {label: _('File'), children: [item('New Finder Window', () => filesAction('new-window')),
            item('New Folder', newFolder), sep, disabled('Open'), disabled('Get Info'), disabled('Move to Trash')]},
        {label: _('Edit'), children: [disabled('Undo'), disabled('Redo'), sep,
            disabled('Cut'), disabled('Copy'), disabled('Paste')]},
        {label: _('View'), children: [item('Show Desktop', () => {
            Main.overview.hide();
            for (const actor of global.get_window_actors()) {
                const win = actor.meta_window;
                if (win?.can_minimize()) win.minimize();
            }
        }), item('Show File Transfers', () => filesAction('show-file-transfers'))]},
        {label: _('Go'), children: [
            item('Home', () => open(Gio.File.new_for_path(GLib.get_home_dir()).get_uri())),
            item('Desktop', () => open(folder(GLib.UserDirectory.DIRECTORY_DESKTOP))),
            item('Documents', () => open(folder(GLib.UserDirectory.DIRECTORY_DOCUMENTS))),
            item('Downloads', () => open(folder(GLib.UserDirectory.DIRECTORY_DOWNLOAD))),
            item('Pictures', () => open(folder(GLib.UserDirectory.DIRECTORY_PICTURES))), sep,
            item('Recent', () => open('recent:///')), item('Trash', () => open('trash:///')),
            item('Computer', () => open('file:///')), item('Network', () => open('network:///'))]},
        {label: _('Window'), children: [item('New Finder Window', () => filesAction('new-window'))]},
        {label: _('Help'), children: [item('Files Help', () => filesAction('help'))]},
    ];
}
